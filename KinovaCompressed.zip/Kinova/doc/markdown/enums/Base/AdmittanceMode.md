# enum AdmittanceMode

## Overview / Purpose

Enumeration AdmittanceMode

|Enumerator|Value|Description|
|----------|-----|-----------|
|UNSPECIFIED\_ADMITTANCE\_MODE|0|Unspecified admittance mode|
|CARTESIAN|1|Cartesian admittance mode|
|JOINT|2|Joint admittance mode|
|NULL\_SPACE|3|Null space admittance mode|
|DISABLED|4|No admittance|

**Parent topic:** [Base \(C++\)](../../summary_pages/Base.md)

