# enum ControllerEventType

## Overview / Purpose

Enumeration ControllerEventType

|Enumerator|Value|Description|
|----------|-----|-----------|
|UNSPECIFIED\_CONTROLLER\_EVENT|0|Unspecified controller event|
|CONTROLLER\_DISCONNECTED|1|Controller is disconnected|
|CONTROLLER\_CONNECTED|2|Controller is connected|

**Parent topic:** [Base \(C++\)](../../summary_pages/Base.md)

