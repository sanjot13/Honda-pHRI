# enum ShapeType

## Overview / Purpose

Enumeration ShapeType

|Enumerator|Value|Description|
|----------|-----|-----------|
|UNSPECIFIED\_SHAPE|0|Unspecified shape type|
|CYLINDER|1|Cylinder shape type|
|SPHERE|2|Sphere shape type|
|RECTANGULAR\_PRISM|3|Rectangular prism shape type|

**Parent topic:** [Base \(C++\)](../../summary_pages/Base.md)

