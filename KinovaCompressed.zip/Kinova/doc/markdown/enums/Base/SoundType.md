# enum SoundType

## Overview / Purpose

Enumeration SoundType

|Enumerator|Value|Description|
|----------|-----|-----------|
|UNSPECIFIED\_SOUND\_TYPE|0|Unspecified sound types|
|BIP\_SERIES|1|Bip series sound type|
|SINGLE\_BIP|2|Single bin sound type|

**Parent topic:** [Base \(C++\)](../../summary_pages/Base.md)

