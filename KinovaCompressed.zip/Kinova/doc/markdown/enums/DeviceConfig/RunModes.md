# enum RunModes

## Overview / Purpose

Enumeration RunModes

|Enumerator|Value|Description|
|----------|-----|-----------|
|RUN\_MODE|0| |
|CALIBRATION\_MODE|1|calibration mode|
|CONFIGURATION\_MODE|2|configuration mode|
|DEBUG\_MODE|3|debug mode|
|TUNING\_MODE|4|tuning mode|

**Parent topic:** [DeviceConfig \(C++\)](../../summary_pages/DeviceConfig.md)

