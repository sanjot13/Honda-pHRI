# enum SafetyLimitType

## Overview / Purpose

Enumeration SafetyLimitType

|Enumerator|Value|Description|
|----------|-----|-----------|
|MAXIMAL\_LIMIT|0|Maximal limit|
|MINIMAL\_LIMIT|1|Minimal limit|

**Parent topic:** [ActuatorConfig \(C++\)](../../summary_pages/ActuatorConfig.md)

