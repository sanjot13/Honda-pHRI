# enum UARTPortId

## Overview / Purpose

Enumeration UARTPortId

|Enumerator|Value|Description|
|----------|-----|-----------|
|UART\_PORT\_UNSPECIFIED|0|Unspecified UART port|
|UART\_PORT\_EXPANSION|1|UART port located on the expansion connector|

**Parent topic:** [InterconnectConfig \(C++\)](../../summary_pages/InterconnectConfig.md)

