# enum GPIOIdentifier

## Overview / Purpose

Enumeration GPIOIdentifier

|Enumerator|Value|Description|
|----------|-----|-----------|
|GPIO\_IDENTIFIER\_UNSPECIFIED|0|Unspecified GPIO identifier|
|GPIO\_IDENTIFIER\_1|1|GPIO identifier 1|
|GPIO\_IDENTIFIER\_2|2|GPIO identifier 2|
|GPIO\_IDENTIFIER\_3|3|GPIO identifier 3|
|GPIO\_IDENTIFIER\_4|4|GPIO identifier 4|

**Parent topic:** [InterconnectConfig \(C++\)](../../summary_pages/InterconnectConfig.md)

