# class CustomDataSelection

 **Member values** 

|Member name|Data type|Description|
|-----------|---------|-----------|
|channel|uint32|16 channels maximum|

 **Member functions** 

|Function name|Return type|Input type|Description|
|-------------|-----------|----------|-----------|
|UNKNOWN\_TO\_DOC: channel|UNKNOWN\_TO\_DOC: channel|UNKNOWN\_TO\_DOC: channel|The message documentation tool does not treat repeated enums.: 14|

**Parent topic:** [ActuatorConfig \(C++\)](../../summary_pages/ActuatorConfig.md)

